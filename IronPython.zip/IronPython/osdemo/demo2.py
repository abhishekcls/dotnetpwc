import os

#os.mkdir('Abhishek')
path=os.getcwd()
print(path)
#print(os.system('dir'))
os.chdir('Abhishek')
path=os.getcwd()
print(path)
#print(os.system('dir'))