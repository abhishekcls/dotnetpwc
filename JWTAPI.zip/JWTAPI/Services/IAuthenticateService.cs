﻿using JWTAPI.Models;


namespace JWTAPI.Services
{
    public interface IAuthenticateService
    {
        User Authenticate(string userName, string Password);
    }
}
