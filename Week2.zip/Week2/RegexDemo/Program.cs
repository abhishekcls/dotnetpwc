﻿using System;
using System.Text.RegularExpressions;

namespace RegexDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            //Regex r=new Regex(@"^\d{5,7}$");
            Regex r=new Regex(@"^\d+$");
            bool res=r.IsMatch("11111111");
            Console.WriteLine(res);
        }
    }
}
//Task
//Take name from user and check whether it has at least 2 chars