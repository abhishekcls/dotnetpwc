#tuples are immutable

fruits=("Apple","Banana","Orange")

print(fruits)
print(type(fruits))

#fruits[1]="Grapes" #error
print(fruits[1])
print(fruits[-2])
print(fruits[2:4])

t1=("apple",)
print(t1)
print(type(t1))

for f in fruits:
    print(f)

if "Apple" in fruits:
    print("Yes its there")
else:
    print("Its not there")

del fruits
#print(fruits)#error

t1=(1,2,3)
t2=(2,2,6,"abc")

t3=t1+t2
print(t3)

print(t3.count(2))