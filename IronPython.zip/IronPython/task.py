"""
n1=int(input("enter 1st no"))
n2=int(input("enter 2nd no"))
n3=int(input("enter 3rd no"))
if (n1>n2 and n1>n3):
    print(n1 )
elif (n2>n1 and n2>n3):
    print(n2)

elif(n3>n1 and n3>n2):
    print (n3)		
"""

'''
n1=int(input('Enter n1'))
n2=int(input('Enter n2'))
n3=int(input('Enter n3'))
if (n1>n2) and (n1>n3):
    print(n1,'is max')
elif(n2>n3):
    print(n2,'is max')
else:
    print(n3,'is max')
'''

n1=int(input('Enter number1: '))
n2=int(input('Enter number2: '))
n3=int(input('Enter number3: '))
print('Maximum of the three numbers is')
if n1>n2:
    if n1>n3:
        print(n1)
    else:
        print(n3)
else:
    if n2>n3:
        print(n2)
    else:
        print(n3)