import re

txt='The rain in Spain'

res=re.search("^The.*Spain$",txt) #Match object
#res=re.search("^The.*Rome$",txt) #None
print(res)

