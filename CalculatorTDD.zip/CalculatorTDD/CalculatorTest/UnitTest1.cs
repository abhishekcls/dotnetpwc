using Microsoft.VisualStudio.TestTools.UnitTesting;
using Calculator;

namespace CalculatorTest
{
    [TestClass]
    public class TestCalculator
    {
        //1. Arrange
        readonly Calc c = new();
        [TestMethod]
        public void Test_Addition()
        {
            //2. Act
            int res = c.Add(2, 3);
            //3. Assert
            Assert.AreEqual(5, res);
            //Act + Assert
            Assert.AreEqual(-5, c.Add(-2, -3));
            Assert.AreEqual(1, c.Add(-2, 3));
            Assert.AreEqual(-1, c.Add(2, -3));
        }
        [TestMethod]
        public void Test_Substract()
        {
            Assert.AreEqual(5, c.Subtract(8, 3));
            Assert.AreEqual(-5, c.Subtract(-8, -3));
            Assert.AreEqual(-11, c.Subtract(-8, 3));
            Assert.AreEqual(11, c.Subtract(8, -3));
        }
        [TestMethod]
        public void Test_Multiply()
        {
            Assert.AreEqual(24, c.Multiply(8, 3));
            Assert.AreEqual(24, c.Multiply(-8, -3));
            Assert.AreEqual(-24, c.Multiply(-8, 3));
            Assert.AreEqual(-24, c.Multiply(8, -3));
        }
        [TestMethod]
        public void Test_Divide()
        {
            Assert.AreEqual(4, c.Divide(8, 2));
            Assert.AreEqual(4, c.Divide(-8, -2));
            Assert.AreEqual(-4, c.Divide(-8, 2));
            Assert.AreEqual(-4, c.Divide(8, -2));
        }
    }
}