#import math
#print(math.sqrt(9))

#from math import sqrt
#print(sqrt(9))

from math import sqrt as sq
print(sq(9))