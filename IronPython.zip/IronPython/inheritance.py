'''
class Parent:
    def disp(self):
        print("Parent")

class Child(Parent):
    pass

c1=Child()
c1.disp()
'''
class Parent:
    def disp(self):
        print("Parent")

class Child(Parent):
    def disp(self):
        print("Child")
        
c1=Child()
c1.disp() 