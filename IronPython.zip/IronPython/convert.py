t1=(1,2,3)

l1=list(t1)

print(t1, type(t1))
print(l1, type(l1))

l1.append(4)
print(l1)