import System

arr = System.Array[int]([1, 2, 3])
print(arr[2])
print(type(arr))

a=System.Int16(5)
print(a)
print(type(a))