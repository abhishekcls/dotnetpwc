#sets
'''
1. no order guaranteed
2. no duplicates
3. cannot access with index -> garpes[2] X
4. 
'''
fruits={"Apple","Banana","Orange"}
print(fruits)
print(type(fruits))

for f in fruits:
    print(f)

if "Apple" in fruits:
    print("Yes its there")
else:
    print("Its not there")

fruits.add("Kiwi")
print(fruits)

#tuple, list, set
#fruits.update({"Grapes","Mango"})
#print(fruits)
#fruits.update(("Grapes","Mango"))
#print(fruits)
fruits.update(["Grapes","Mango"])
print(fruits)

print(len(fruits))

fruits.remove("Kiwi")
print(fruits)

#errors
#fruits.remove("Papaya") # KeyError
#print(fruits[1]) # TypeError

print(fruits.pop())
print(fruits)

fruits.clear()
print(fruits)

del fruits
#print(fruits)#NameError

s1={1,2,3,4}
s2={4,5}

#s3=s1+s2#TypeError
s3=s1.union(s2)
print(s3)

s1.update(s2)
print(s1)
print(s2)

t1=(1,2,3)
set1=set(t1)
print(t1, type(t1))
print(set1,type(set1))