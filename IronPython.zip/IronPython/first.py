print('hello')
print("hello")