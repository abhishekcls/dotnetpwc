n1=10
n2=5

print(n1)
print(type(n1))
print(n1+n2)
print(n1/n2)#float
print(n1//n2)#int
print(5**2)

f=5.7
print(f,type(f))
print(type(f) is float)
print(isinstance(f,float))
print(type(f) is int)
print(isinstance(f,int))

s1='abc'
s2="xyz"

print(s1,s2)
print(type(s1),type(s2))

x=1-5j
print(x)
print(type(x))
print(x.real)
print(x.imag)

b=True
print(b,type(b))