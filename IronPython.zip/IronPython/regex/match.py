import re

phone=['9878636552','8878636552','4878636552','7878636552','98786365527']

for p in phone:
    if re.match(r'[7-9]{1}[0-9]{9}',p) and len(p)==10:
        #print(f'{p} is Valid')# python 3.6
        print(p,'is Valid')
    else:
        print(p,'is Invalid')
