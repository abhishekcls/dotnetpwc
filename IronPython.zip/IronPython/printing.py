a='Abhishek'
b=10

print('Hello '+a)
print('Welcome',a)
print('Hi {} {}'.format(a,b))
print('Hey %s %d'%(a,b))