for i in range(5):
    print(i)

print("="*10)

for i in range(1,5):
    print(i)

print("="*10)

for i in range(1,10,2):
    print(i)

print("="*10)

for i in range (5,0,-1):
    print(i)

print("="*10)
i =1
while i<=5:
    print(i)
    i+=1 