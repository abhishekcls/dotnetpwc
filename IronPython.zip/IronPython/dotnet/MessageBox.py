import clr

clr.AddReference("System.Windows.Forms")

from System.Windows.Forms import MessageBox, MessageBoxButtons

#res=MessageBox.Show("Hello World!", "Greetings", MessageBoxButtons.OKCancel)
#res=MessageBox.Show("Hello World!", "Greetings", MessageBoxButtons.YesNo)
res=MessageBox.Show("Hello World!", "Greetings", MessageBoxButtons.YesNoCancel)

print(res)
