class Demo:
    pass

d1=Demo()

print(type(d1))

class Demo2:
    name="Abhishek"
    def show(self):
        print("Hello "+self.name)

d2=Demo2()
d2.show()
print(d2.name)

#cons -> __init__
#des -> __del__

class Student:
    def __init__(self,name):
        print('cons')
        self.name=name
    def __del__(self):
        print('des')

#__ dunder -> double underscore
s1=Student("Harsh")
s2=Student("Uday")

print(s1.name)
print(s2.name)