class Father:
    def __init__(self):
        print("Father cons")

class Mother:
    def __init__(self):
        print("Mother cons")

class Child(Father,Mother):
    def __init__(self):
        Father.__init__(self)
        Mother.__init__(self)
        print("Child cons")

c1=Child()