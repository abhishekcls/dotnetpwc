'''
def add(a,b):
    return a+b
'''


#add=(a,b)=>a+b
add=lambda a,b:a+b
print(add(2,3))
# lambda parameters:body
