#list is mutable
#list is similar to array in js

fruits=["Apple","Banana","Orange"]
print(fruits)
print(type(fruits))
print(fruits[1])

for f in fruits:
    print(f)

if "Apple" in fruits:
    print("Yes its there")
else:
    print("Its not there")

print(len(fruits))
fruits.append("Kiwi")
print(fruits)
print(len(fruits))

fruits.insert(1,"Mango")
print(fruits)

fruits[2]="Grapes"#update/replace
print(fruits)

fruits.remove("Grapes")
print(fruits)

fruits.pop()
print(fruits)

del fruits[0]
print(fruits)

copy=fruits.copy()
fruits.clear()
print(copy)
print(fruits)

l1=[1,2,3]
l2=[4,5,6]

l3=l1+l2
print(l3)

lst1=[1,2,3]
lst2=['abc','xyz']

lst3=lst1+lst2
print(lst3)
lst1.extend(lst2)
print(lst1)

scores=[2,5,7,89,34]

print(scores)
print(scores[3])
print(scores[-3])
print(scores[2:4])
print(scores[0:2])
print(scores[3:])
print(scores[:3])
print(scores[0:5:2])