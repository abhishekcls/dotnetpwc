﻿namespace JWTAPI.Models
{
    public class AppSettings
    {
        public string Key { get; set; }
    }
}
